


def cost(G, e):
    return G.edges()[e]['weight']
